Kimpo is a sans-serif font made to resemble my own handwritting, with each character having been drawn by hand.

The Kimpo font is available in a 172-character file, in both regular and bold. 

Available in .otf and .ttf files. The font is free for personal or commercial use

This typeface was developed as a personal project, for my own entertainment. If you like it, please consider donating to help support a small artist!

For more information, 
shoot me an email at imelliot.c@gmail.com


Thank you!

Elliot