This End User License Agreement (EULA) is a legal agreement between the Licensee and Noel Hoe.


You agree to the terms of this agreement by purchasing, downloading, installing, or otherwise using the project work files. The term "project work files" refers to computer design software Adobe project files. This agreement governs your acquisition and use of the work files.

Please read this End User License Agreement (EULA) carefully before completing the installation, importation, or using the work files. It provides a license to use the project work files and contains warranty information and liability disclaimers.


You are permitted to:

- Download and utilize the work files in unlimited copies.

- Edit, alter, modify, adapt, or change the whole or any part of the work files.

- Utilize the work files for commercial purposes.


You are not permitted to:

- Reproduce, copy, distribute, resell or otherwise use the work files to others.

- Allow any third party to use the work files on behalf of or for the benefit of any third party.

- Use the work files in any way which breaches any applicable local, national or international law.


Any suspicious purposes on utilizing the work files that Noel Hoe considers are a breach of this agreement; your rights and your license on using the Adobe work file will be terminated.

*The agreement terms may be modified or updated at any time without notice.


For any inquires, please get in touch with me via email

Thank you,

From Noel. ✌︎