Hello,

Thank for downloading Romantically



NOTE: This demo font is for PERSONAL USE ONLY! 


Link to purchase full version and commercial license:

Please visit our store for more great fonts :
https://thehungryjpeg.com/product/3524569-romantically




If there is a problem, question, or anything about my fonts, please sent an email to

panggahlaksono@gmail.com




Thanks,


ABODNYL