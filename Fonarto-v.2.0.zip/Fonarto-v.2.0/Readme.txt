Fonarto Font

Fonarto is a sans serif font that is combined with classic shape in some parts.  It makes Fonarto has a modern style with classic impression.

Free for personal and commercial purpose.

Changelog v.1.2:
- Update multilanguage support.
- Kerning refined.

Changelog - December 2019:
• New styles: Light, Regular, Bold.
• Support for 28 languages.
• Fix improper kernings.
• Fix some inconsistent characters.

-----------
©2019 LOCOMOTYPE
http://locomotype.com
Email: locomotype@gmail.com