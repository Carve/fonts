ABOUT:
Rahovets is an ancient settlement and fortress located near the town of Gorna Oryahovitsa in Bulgaria. Rahovets by Fontease is a free font inspired by an inscription on the most popular Bulgarian compact oven from the communist era, which bears the same name. Have fun! Enjoy our free font! :)

LICENSE:
Please read the attached EULA!

CONTACT:
tease@fontease.com