Hello,

Thank for downloading Creattion

NOTE: This font is FREE 100% FOR PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/dimasardhi

Please follow our instagram for update : @glyphstyle

Contact us : styleglyph@gmail.com




How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

How to Using Special Characters

https://helpx.adobe.com/illustrator/using/special-characters.html

Thanks,


GlyphStyle