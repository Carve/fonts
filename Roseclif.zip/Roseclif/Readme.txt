Hai,

Thank for downloading this font!

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:
	• This font is ONLY for PERSONAL USE.
	• If you need a custom license please contact us at
firstype1@gmail.com 
If you want to donation are very appreciated.
Paypal account : paypal.me/firstype

Thank you :D

----------