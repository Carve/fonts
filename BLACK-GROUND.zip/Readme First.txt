Thanks for downloading!

===================================================

Official Store:
https://www.garisman.com/

===================================================

NOTE:
- If there is a problem, question, or anything about my fonts, please sent an email to:
support@garisman.com



- Available for Extended License (visit our Official Store)
- Share your work with this font and tag us on instagram @grsmn.id

================

Thanks,

Garisman Studio