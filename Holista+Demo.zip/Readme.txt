Hello,

Thanks for downloading Holista
NOTE: This font is FREE 100% FOR PERSONAL USE ONLY! But any donation are very appreciated. 

visit our website for FULL VERSION font: https://www.glyphstyle.net/shop/

Paypal account for donation : https://www.paypal.me/dimasardhi

Please follow our instagram for update : @glyphstyle

Contact us :admin@glyphstyle.net 



How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

How to Using Special Characters

https://helpx.adobe.com/illustrator/using/special-characters.html

Thanks,


GlyphStyle