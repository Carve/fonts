VALENCIAGA - A Font by Aluyeah Studio

Please read this before using the font.

You may use this version of 'VALENCIAGA' for personal use only.  If you wish to use it commercially you will need to purchase a license. Click here 

https://fontbundles.net/aluyeahstudio/392131-al-valenciaga

You may like our other product

https://fontbundles.net/aluyeahstudio
https://www.creativefabrica.com/designer/aluyeah-studio/

Any Question, you can submit your question here

https://www.behance.net/aluyeahstudio

PLEASE FOLLOW & APPRECIATE OUR PROJECT, Uyeah Mamen! 
