Hello,

Thank for downloading Vallery Qylmor.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase full version and commercial license: 
https://creatypestudio.co/vallery

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at
foundry@creatypestudio.co

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/CreatypeStudio
 
Please visit our store for more amazing fonts : 
https://creatypestudio.co

Follow our instagram for update : @creatypestudio

Thank you.