_____________________________________________________________________

Romance Fatal 2.00
(Aflicci�n)
Version 2.00 

Copyright (c) 2009 Juan Casco. All Rights Reserved.
http://www.juancascofonts.blogspot.com/
metanorocker14@hotmail.com
_____________________________________________________________________
Font free ware, for personal use
for comercial use contact me by e-mail

Description:
Based in my handwriting