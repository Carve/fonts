dandelion in the spring (c) Brittney Murphy 2011
www.brittneymurphydesign.com
info@brittneymurphydesign.com

"Dandelion in the Spring" is a font created and copyrighted by Brittney Murphy.

It is free for personal and non-profit use.  Commercial use is $5.

You are free to redistribute (not sell) this font as long as you include this ReadMe file with the font file and don't try to claim the font as free or as your own.

