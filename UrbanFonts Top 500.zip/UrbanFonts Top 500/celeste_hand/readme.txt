Thanks for downloading Celeste Chang by AllencHIU cHIU

Free for personal use.
For commercial usage, a small donation of any amount is appreciated but not required.
Donate link: https://www.paypal.com/us/cgi-bin/webscr?cmd=_flow&SESSION=aEww1oFPEIRWkNAhWg0P6ffB9GdpXGJ1Bycsh8l_YhnPPCnZn6lCPX-v--K&dispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b833248354cf50881b500d37e944d21e525ac7f200bc6a344

I love to see my fonts being used, so e-mail me!
(or contact me using your preferred method of contact)

e-mail: pealwah@hotmail.com
aim: alwaysbehappy135
site: http://asianpride7625.deviantart.com/




Sebastian 1>2