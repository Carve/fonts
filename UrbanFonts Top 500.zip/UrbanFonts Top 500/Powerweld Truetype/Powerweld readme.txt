This Font I created for my own use in my pump-manufactory. 

If you like it, please drop me a note at: wiegel@aepnet.de

This Font is freeware. However it is Not Public Domain.
You are allowed to share this font (including this readme-file) without asking for any fee and to use it however and howoften you want.
If you want to add this to your Font-Download-Page, please drop me a note.
And please ask me, if you want to put it on a commercial Font-CD ore some other commercial software product.

(c) P. Wiegel CAT-Design Wolgast
