This font is free for personal use only.  Contact me for any information on commercial use.
All of the artwork on the fonts, dingfonts, and dingbats is my own.  Please contact me for permission before adding the download of this font on your site, and I require a link to my webpage.
Please don't distribute this without this read-me file, or offer it for sale on a CD for commercial purposes without contacting me first.

Jeri Ingalls

e-mail:  ingalls@kalama.com
http://www.littlehouse.homestead.com