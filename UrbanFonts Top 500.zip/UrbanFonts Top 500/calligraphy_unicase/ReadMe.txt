Type Fetish End Users Licence Agreement (EULA) for Freeware Fonts

version 2.0, April 2010

I ask that you respect my work and follow a few simple rules. If you do not wish to or can not agree to the terms, please do not download the font.

You may distribute the font as long as you keep all the files together. You may upload the font to a font archive page as long as all the files are included, I am credited as the designer and there is a link to www.typefetish.com.

You may make derivative works from this typeface as long as you send me a copy of the font, give me credit, release it as freeware and link to www.typefetish.com

You will not sell this typeface, or any derivative works, either individually or in a package.

If you are making money using this typeface then I should make some money for making it. All I am asking for is about $5 per font. Contact me for payment information at michael@typefetish.com.