
                      JAMAISTEVIE FONT
This font is free for use.I made it because there are few cyrilic fonts that u can use free..
 Author:jamaisvu- jamais_vu@mail.bg
 