Thanks for downloading a Penny Font! 
I have just a few small guidlines pertaining to the use of my fonts. 

1. I do not allow the use of my fonts for any "Evil Empires" so-to-speak. These include but are in no way limited to Nike, Walmart, Gap, McDonalds, etc. Basically, any large corporation that degrades the standard of life, human or otherwise. 

2. I do not allow the use of my fonts for any group or organization I feel does a disservice to mankind. This includes but is not limited to any Hate Group, Government Ogranization, or any Religious organizations that promote racism or homophobia as a doctrine.

3. You may not distribute my fonts without prior consent.

Those are my simple terms. I would also ask that if you use a font for something, drop me a line and let me know, I like to hear about it! 

Check back often for more new fonts! 

http://www.pennyzine.com
thehandbook@hotmail.com