Photonica Regular + Straight

Background
Thank you for downloading this set of fonts. Based on Malaysia's national car logotype, it started out by taking pictures of other people's car and then tracing the word "proton". Then the other alphabets are created based on those initial characters. It took me quite a bit to finish both versions, particularly when adjusting substantially large number of kerning pairs.

Enjoy using these fonts as much as I have in creating them.

Using the fonts
You may use this font for FREE commercially and non-commercially. All I ask for is that you send me a screenshot or a scanned picture of its application, or send me the URL to the website that you used it on, as I'd like to see how far these fonts go.

Distribution
You may redistribute this set provided that you keep all the fonts as a set and this readme file together. If you wish to include this set in a magazine/book CD-ROM, I would like to have a copy of the magazine sent to me. Please e-mail me for the address to send it to.

Created on Adobe Illustrator and Macromedia's Fontographer on a iMac DV400 (Tangerine).

Contacting the author
creator: Sean Liew
website: http://www.cmonsta.com
e-mail: sean@cmonsta.com

January 2002 � The fonts "PhotonicaRegular" and "PhotonicaStraight" are (c) 2002 Liew Kheng Huat, All rights reserved