   font: headthinker
 author: ugghhzilla (ugghhzilla.deviantart.com)
version: 1.0
contact: 1headthinker@gmail.com

Usage:
Free for personal and commercial use.
If possible please send me a link to 
where font has been used.  This is 
purely for the purposes of stroking my
ego and is not a requirement of usage.

Enjoy!
