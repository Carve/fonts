  ____                _      _    ____              _    
 / ___|___  _ __ ___ (_) ___| | _| __ )  ___   ___ | | __
| |   / _ \| '_ ` _ \| |/ __| |/ /  _ \ / _ \ / _ \| |/ /
| |__| (_) | | | | | | | (__|   <| |_) | (_) | (_) |   < 
 \____\___/|_| |_| |_|_|\___|_|\_\____/ \___/ \___/|_|\_\
                                                         

A font for comics.

It's not perfect, but I think it's pretty snazzy.

Feel free to post this on other sites... just give credit to me. And preferably a link to http://www.oufoufsworld.co.uk.

ouf-ouf
