                             ,---------------------------------.
                           -=    Subatomic Tsoonami v0.0.8      =-
                             `---------------------------------'

Author:              subatomic

Contents:            "Subatomic Tsoonami" True Type Font

Price:               Free, but if you improve it, send back changes
                     with your reason for the change.

Description:         this is a font similar to the 2004 Toonami font used
                     on Cartoon Network.

Contact Information: kevin@subatomicglue.com
                     http://www.subatomicglue.com
                     or use google for subatomicglue or kevin meinert,
                     google rocks.

Legal:               LGPL license (www.opensource.org)
                     (C) 2004 Subatomic
                     See the file COPYING.txt for general terms and conditions.

                     Before including on any compilations please notify me.
