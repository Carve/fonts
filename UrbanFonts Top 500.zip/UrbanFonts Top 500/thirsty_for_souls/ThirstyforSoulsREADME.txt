           __________   __________  ____    ___    __   ______________
    /\    / /_  __/ /  / /_  __/ / / ___\  / _ \  / /  / /_  __/___  /
   /  \  / / / / / /__/ / / / / / / /___  / / \_\/ /__/ / / /     / /
  / /\ \/ / / / / ___  / / / / /  \____ \/ /  __/ ___  / / /     / / FONTS
 / /  \  /_/ /_/ /  / /_/ /_/ /_______/ /\ \_/ / /  / /_/ /_    / /____
/_/    \/_____/_/  /_/_____/_____/\____/  \___/_/  /_/_____/   /______/

Thirsty for Souls v1.0

I made this one for my bestest best friend Bwomp, because he is the
devourer of souls.  I'm pretty proud of the fact that this one lines
up all nice.  This is the first time I even attempted that.  And most
of the letters are the same height as other similar letters.  It looks
all professional and scary.  It also looks like someone splashed white
paint all over it, or something.

This font is free, and you can do whatever you want with it, for your 
personal use.  If you want to distribute this font, that's fine.  Just 
keep this text file with it so people know who made it.  You can 
distribute it on any free font websites or any other form you want, as 
long as you keep it free and don't claim you made it.  Cause you didn't.  
No selling it, or claiming it as your own.  If you want to use this 
font to make something really cool, just email me about it to get 
permission.  I'll want a copy of whatever you make.  If you make money 
off my font, I want some too.  No commercial use without my permission
first.

Speaking of money, if you like my font a lot and want to give me money,
I'd love that.  Donations are awesome and therefore people who donate
are awesome. Email me and we could work something out, and then maybe
I'll give you something super awesome as well.  A drawing, a custom
stenciled t-shirt, I make stuff like that.  Depends on if I'm feeling
generous.

Email me if you like my font, or if you want to make some spiffy stuff 
with it, or stuff.

nihilschiz@herzeleid.net
http://nihilschiz.sheezyart.com
Check this site for some of my artwork.