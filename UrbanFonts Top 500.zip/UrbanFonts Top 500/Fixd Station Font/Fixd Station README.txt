Hey there,

Thankyou for downloading this font. You will notive this has normal character, CAPS and some symbols. Not everything is done becuase I wanted a simple font - and ran out of time to do the rest. If you would like to complete the font, let me know.

This is a free font, it can be used on anything and everything. However, if you use it on works where you receive payment, contact me and we will work out the royalties. Don't make me chase you down. lol.

Seriously though, if you do use this, please link to my blog - www.thinkingdiesel.com - or my website - www.fixdmusic.com - and remember, what goes around comes around.

Enjoy it, looking forward to seeing what you do with this font.


-Diesel

Email me: diesel@thinkingdiesel.com
Web: www.thinkingdiesel.com
www.fixdmusic.com