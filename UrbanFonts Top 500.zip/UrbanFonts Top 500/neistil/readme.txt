******************************************************
* The Dionaea Fonts are made by Svein K�re Gunnarson *
*   http://www.dionaea.com/information/fonts.html    *
*                                                    *
*               The fonts are freeware               *
******************************************************