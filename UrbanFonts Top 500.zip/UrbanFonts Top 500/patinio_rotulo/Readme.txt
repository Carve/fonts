Todas las fuentes son derecho de autor Ricardo Arley Pati�o Pe�a (iAgency 1980) ( http://www.iagency1980.com -  
http://elfactorvector.blogspot.com)

Este es un tipo de letra freeware. Esto significa que usted puede utilizar la fuente en su trabajo comercial o no comercial de forma gratuita.

Pero aqu� hay una lista de cosas que podr�as hacer, s�lo si quieres:

* enviarme un correo acerca de su obra
* Enlace ( rycardoarley@hotmail.com )
* Enviarme una muestra del trabajo que hizo con mi tipo de letra
* Cr�dito "iAgency 1980 ( interactive agency )" o "Ricardo Arley Pati�o" en su trabajo
* Sonrisa

ponerse en contacto con rycardoarley@hotmail.com en Colombia


Ricardo Arley Pati�o Pe�a
iAgency 1980.