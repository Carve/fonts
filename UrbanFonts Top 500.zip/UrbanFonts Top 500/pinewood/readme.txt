PINEWOOD (ver. 1.01) copyrighted 1993, all rights reserved.

Pinewood is a typeface used mainly for display work. It's great in: ads, newsletters, headlines, or for any desktop publisher who wants that something �extra� to stand out in their design work. Note: this typeface will use more memory than most, so don't download a lot of different fonts when you use this one or you'll overload your printer's memory. If you're using Adobe's Type Manager, you may tax it's memory use as well.  Remember, even if you use this font only once, it's well worth the price (See below).


WHAT'S INCLUDED?
IF TYPE ONE FONT:
"Pinew" -the print driver.
"Pinewood.b.map" -the screen font of 48 pt. ( Note: bitmaps are not cleaned up, use Adobe Type Manager for screen display or the TrueType version.)
"About PINEWOOD Font�"- the text file you're reading now.

IF TRUE TYPE FONT:
"Pinewood.suit" -the screen/print driver. (Font file)
"About PINEWOOD Font"- the text file you're reading now.

You may upload these files to other bulletin boards provided all files are included without alteration. 

WHAT'S NOT INCLUDED.
No assumption of liability of any kind, for any reason.

If you find this typeface useful please send $3.00 and, an example of it's use, (an ads, newsletter, or Brochure, etc.) to the address below.

             Rick W. Mueller
             Type Offer
             R.R. 1, Box 108
             Elkader, IA  52043-9727

Enjoy,


Rick,  Feb. '93