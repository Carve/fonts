Mojotype v1.0
----------------------------------
A freeware font by John Flickinger
http://www.webdesignfire.com | http://www.typemylogo.com
webdesignfire@gmail.com
----------------------------------

This package includes:
----------------------
Mojotype.otf
mojotype.png
This readme.txt


Changelog
---------


v1.0 January 29, 2008
Initial Release



USAGE
-----
This is a display typeface intended for LARGE titles and looks it's best around 96pt.

This font is free for personal or commercial use. You may use it freely, add it to your website, or distribute it in any digital format you wish for free as long as it includes the files listed above unaltered in any way. If you do use this font in a commercial project, or add it to a site, I would appreciate an e-mail showing me how it was used but you're not required to notify me. 


I'm not happy with the way parts of this font came out, so there will probably be an update down the line, so check back if you're interested.