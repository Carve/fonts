"Baccer" is a western woodcut-type font loosely based on the logo of a long-leaf tobacco pouch. My great grandfather used to ask if I'd "like some 'baccer'".

===========================================================
Majik Mike's Fonts are FREE.
===========================================================
They were created solely by myself, but you are welcome to redistribute, alter and de-engineer the font.
You have my blessing if your company wishes to incorporate it or to make a return from its graphical use.
===========================================================
YOU ARE NOT ALLOWED TO SELL OR REMARKET THIS FONT!
===========================================================
Please retain the name of the font, but you may add a second name to help describe it if you wish.

REQUEST:
My fonts are NOT technically perfect. They need metrics and better kerning assignments.
If you are able to work on the font, add characters or tweak the metric
please email a copy to me for my collection and/or re-release.

Contact Mike at:
majikmike@mail.com