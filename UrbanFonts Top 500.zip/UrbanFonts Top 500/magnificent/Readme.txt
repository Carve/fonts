A�o: 2009
Nombre: Magnificent
Dise�ador: Diego Vallejo

Contacto:
Mail/MSN: diego_vallejo_88@hotmail.com