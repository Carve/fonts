FAT CAT is copyright 2011 KC Fonts all rights reserved. 

This font is free for PERSONAL USE ONLY.

You are not permitted to use the font in public media unless permission is given.

Please contact kcfonts@gmail.com for more info or to obtain a commercial license.

www.kcfonts.com

www.fb.com/KCFonts