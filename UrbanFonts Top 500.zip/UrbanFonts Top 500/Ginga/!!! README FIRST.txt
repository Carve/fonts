




Instruction:

use The symbols > and < to make the end of the words. the "tail"



Ginga font

by BillyArgelFonts 2008

for personal use only

commercial licenses and embeddable version available

contact billyargel@gmail.com

visit http://billyargel.blogspot.com/
