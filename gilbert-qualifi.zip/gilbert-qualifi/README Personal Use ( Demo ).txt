
	
	

	Welcome !!

	Thankyou for using this font :)

	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	|  WARNING : You can use this font only for "Personal Use"  |
	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	For COMMERCIAL / CORPORATE use you can Purchase from :

	https://fontbundles.net/embuntype/1642724-gilbert-qualifi-classy-serif-font

	-
	
	If you want to create Custom font, Lettering or Logotype
	you can contact us at :

	embunstudio2018@gmail.com

	-

	Visit Our Store for another Great and Cool Font :

	https://fontbundles.net/embuntype

	-

	Support me with donate at :

	https://www.paypal.me/aditrezki

	-

