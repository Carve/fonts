EP Stellari Display Font free to use for personal and commercial projects. It's available only is UPPERCASE. 

EP Stellari Display Font is created by Designer and Art Director Edy Pang @edypang). 

Read license at https://edypang.com/type/lisences.