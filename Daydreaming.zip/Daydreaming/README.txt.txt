Thanks for downloading!

This font is free for all uses, including commercial projects, 
without any restrictions. 
You are free to use, modify, and redistribute it as you see fit.

Enjoy using the font, and feel free to share it with others.

You can contact me:
maisuradzeteona99@gmail.com