# Google Sans web fonts
Google Sans, Google Sans Display & Gallery Icons web fonts

## Source
* TTF: [Google Git](https://bit.ly/GoogleSans)

## Conversion programs
* **TTF to WOFF**: `sfnt2woff` (from package [`woff-tools`](https://packages.ubuntu.com/woff-tools))
* **TTF to WOFF2**: `woff2_compress` (from package [`woff2`](https://packages.ubuntu.com/woff2))
