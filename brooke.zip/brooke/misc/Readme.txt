NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.

Paypal account for donation : nofisofyanhadi@gmail.com

Link to purchase full version and commercial license:
- Creative Market : https://crmrkt.com/VoNPjW

- Font Bundles : https://fontbundles.net/heinzelstd/739018-brooke-serif/rel=WeeBFe

Please visit our store for more great fonts :
- Creative Market : https://creativemarket.com/heinzel?u=Heinzel

- Font Bundles : https://fontbundles.net/heinzelstd/rel=WeeBFe

Thank you.
-----------------------------------------

INDONESIA:

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

1. Font ini hanya dapat digunakan untuk keperluan "Personal Use", atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font saya. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, atau Perusahaan/Korporasi.   

2. DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, atau untuk Kemasan Produk ( baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

3. Menggunakan font ini untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari saya, akan dikenakan biaya EXTENDED LICENSE atau 100 kali lipat dari Lisensi Standard.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi saya:
Email: nofisofyanhadi@gmail.com

Terima kasih

regards,

Nofi Sofyan Hadi